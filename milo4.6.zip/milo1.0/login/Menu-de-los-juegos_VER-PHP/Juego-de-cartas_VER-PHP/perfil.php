<?php
session_start();

// Validar inicio de sesión real
if (!isset($_SESSION['usuario'])) {
    header("Location: /milo1.0/login/index.php");
    exit();
}

$usuario_actual = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mailo - Mis Trofeos</title>

    <!-- Estilos generales y del sidebar -->
    <link rel="stylesheet" href="../../style.css">

    <!-- ESTILOS ESPECÍFICOS PARA LAS TARJETAS (Para solucionar que se vea como texto plano) -->
    <style>
        .zona-trofeos {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            width: 100%;
        }

        .contenedor-trofeos {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            width: 100%;
            max-width: 900px;
        }

        .tarjeta-trofeo {
            background-color: #92b7c0;
            border: 3px solid #fff;
            border-radius: 30px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            color: #1e3842;
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
            position: relative;
        }

        .icono-trofeo {
            font-size: 3rem;
            margin-bottom: 8px;
            filter: drop-shadow(0 4px 6px rgba(0,0,0,0.2));
        }

        .nombre-trofeo {
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 5px;
            color: #ffffff;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }

        .descripcion-trofeo {
            font-size: 0.85rem;
            color: #e0f2f1;
        }

        /* ESTADO BLOQUEADO (Gris y semitransparente) */
        .tarjeta-trofeo.bloqueado {
            opacity: 0.45 !important;
            filter: grayscale(90%) !important;
            background-color: #72969f !important;
        }

        /* ESTADO DESBLOQUEADO (Color nítido) */
        .tarjeta-trofeo:not(.bloqueado) {
            opacity: 1 !important;
            filter: none !important;
            background-color: #92b7c0 !important;
        }
    </style>
</head>
<body>

    <div class="pantalla-principal">
        
        <div class="contenido-izquierdo">
            <header class="encabezado">
                <div class="logo-mailo">
                    <span>🐶 MAILO</span>
                </div>
                <h1 class="titulo-principal">Tus Trofeos Obtenidos</h1>
            </header>

            <main class="zona-trofeos">
                <!-- CONTENEDOR DE TROFEOS -->
                <div class="contenedor-trofeos">
                    <div class="tarjeta-trofeo bloqueado" data-id="trofeo-flash">
                        <div class="icono-trofeo">⚡</div>
                        <div class="nombre-trofeo">Rayo Flash</div>
                        <div class="descripcion-trofeo">Completa el juego en menos de 1 minuto.</div>
                    </div>

                    <div class="tarjeta-trofeo bloqueado" data-id="trofeo-promedio">
                        <div class="icono-trofeo">⚙️</div>
                        <div class="nombre-trofeo">Constante y Seguro</div>
                        <div class="descripcion-trofeo">Completa el juego en menos de 2 minutos y medio.</div>
                    </div>

                    <div class="tarjeta-trofeo bloqueado" data-id="trofeo-tortuga">
                        <div class="icono-trofeo">🐢</div>
                        <div class="nombre-trofeo">Sin Prisa pero Sin Pausa</div>
                        <div class="descripcion-trofeo">Completa el juego tomándote tu tiempo.</div>
                    </div>
                </div>
            </main>

            <footer class="pie-pagina">
                <p>MAILO - Plataforma Educativa e Infantil</p>
            </footer>
        </div>

        <?php include '../../sidebar.php'; ?>

    </div>

    <!-- 1. INYECTAMOS EL USUARIO ACTUAL A JAVASCRIPT -->
    <script>
        window.usuarioLogueado = "<?php echo htmlspecialchars($usuario_actual); ?>";
        console.log("Usuario actual en sección trofeos:", window.usuarioLogueado);
    </script>

    <!-- 2. SCRIPT DE SINCRONIZACIÓN -->
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const usuarioActual = window.usuarioLogueado || "invitado";
            const claveStorage = 'trofeos_mailo_' + usuarioActual;
            
            console.log("Buscando trofeos en la clave:", claveStorage);
            const trofeosObtenidos = JSON.parse(localStorage.getItem(claveStorage)) || [];
            console.log("Trofeos encontrados:", trofeosObtenidos);

            const tarjetasTrofeo = document.querySelectorAll('.tarjeta-trofeo');

            tarjetasTrofeo.forEach(tarjeta => {
                const idTrofeo = tarjeta.getAttribute('data-id');

                if (trofeosObtenidos.includes(idTrofeo)) {
                    tarjeta.classList.remove('bloqueado');
                    console.log(`Trofeo desbloqueado visualmente: ${idTrofeo}`);
                } else {
                    tarjeta.classList.add('bloqueado');
                }
            });
        });
    </script>
</body>
</html>