<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Sesión no iniciada']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

$idTrofeo     = trim($input['id_trofeo'] ?? '');
$nombreTrofeo = trim($input['nombre_trofeo'] ?? '');
$iconoTrofeo  = trim($input['icono_trofeo'] ?? '');
$usuario      = $_SESSION['usuario'];

if ($idTrofeo === '' || $nombreTrofeo === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Datos de trofeo incompletos']);
    exit();
}

$host    = 'localhost';
$db      = 'trofeos_usuario';
$user    = 'root';
$pass    = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    // ¿El usuario ya tiene este trofeo?
    $stmtCheck = $pdo->prepare(
        'SELECT id FROM trofeos_usuario WHERE usuario = :usuario AND id_trofeo = :id_trofeo LIMIT 1'
    );
    $stmtCheck->execute([
        ':usuario'   => $usuario,
        ':id_trofeo' => $idTrofeo
    ]);

    if ($stmtCheck->fetch()) {
        echo json_encode([
            'ok'    => true,
            'nuevo' => false,
            'msg'   => 'El usuario ya tenía este trofeo previamente.'
        ]);
        exit();
    }

    // Insertar nuevo trofeo
    $stmtInsert = $pdo->prepare(
        'INSERT INTO trofeos_usuario (usuario, id_trofeo, nombre_trofeo, icono_trofeo)
         VALUES (:usuario, :id_trofeo, :nombre_trofeo, :icono_trofeo)'
    );
    $stmtInsert->execute([
        ':usuario'       => $usuario,
        ':id_trofeo'     => $idTrofeo,
        ':nombre_trofeo' => $nombreTrofeo,
        ':icono_trofeo'  => $iconoTrofeo
    ]);

    echo json_encode([
        'ok'    => true,
        'nuevo' => true,
        'msg'   => '¡Trofeo guardado en MySQL!'
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    // 'detalle' ayuda a depurar; bórralo cuando todo funcione
    echo json_encode([
        'ok'      => false,
        'error'   => 'Error al guardar en base de datos',
        'detalle' => $e->getMessage()
    ]);
}